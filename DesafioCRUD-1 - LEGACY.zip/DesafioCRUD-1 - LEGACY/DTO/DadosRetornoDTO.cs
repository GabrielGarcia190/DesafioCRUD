﻿namespace DesafioCRUD.DTO
{
    public class DadosRetornoDTO
    {
        public bool Sucesso { get; set; }
        public string MensagemErro { get; set; }
    }
}
